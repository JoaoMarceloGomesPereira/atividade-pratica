package ObjetoGeometrico;

public interface interfaceGeometria {


    double getArea();
    double getPerimetro();
}